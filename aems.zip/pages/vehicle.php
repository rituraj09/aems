<?php
include("../config.php"); 
include("../layout/header.php"); 
$name = "";
$vehicle_name_err="";
$reg =""; 
$reg_err="";
$owner ="";
$owners_err="";
$owner_ph ="";
$owner_ph_err="";
$driver ="";
$driver_err="";
$driver_ph ="";
$driver_ph_err=""; 
$type =""; 
$type_err="";
$seat =""; 
$seat_err="";
$used_from =""; 
$date_on_err="";
$fuel="";
$fuel_err="";
$used_err="";
$used_type="";
$ok_username = "";
$msg="";  
if(isset($_POST['Submit']))
{

    $reg =  trim($_POST['reg']);
    $name =   $_POST['name']; 
    $owner =  $_POST['owner']; 
    $owner_ph =  $_POST['owner_ph']; 
    $driver =  $_POST['driver']; 
    $driver_ph =   $_POST['driver_ph']; 
    $type =  $_POST['type']; 
    $seat =  $_POST['seat']; 
    $used_from =  $_POST['used_from'];  
    $fuel =  $_POST['fuel'];  
    $used_from =  $_POST['used_from'];  
    $used_type =  $_POST['used_type'];  
  
    if(empty($_POST["name"])){
        $name_err = "Please enter Vehicle Name.";
    } 
    elseif(empty(trim($_POST["reg"]))){
        $desig_err = "Please enter the Vehicle Registration Number.";
    } 
    elseif(empty(trim($_POST["phone"]))){
        $phone_err = "Please enter a Phone Number.";
    } 
    elseif(empty($_POST["type"])){
        $type_err = "Please select the type.";
    } 
    elseif(empty($_POST["password"])){
        $password_err = "Please enter the password.";
    }    
    elseif(strlen(trim($_POST["password"])) < 6){
        $password_err = "Password must have atleast 6 characters.";
    }
    elseif(empty($_POST["confirm_password"])){
        $confirm_password_err = "Please confirm the password.";
    }
    elseif($_POST["password"]!=$_POST["confirm_password"]){
        $confirm_password_err = "Password not matching.";
    }
    else
    {  
        $s = "SELECT count(1) as cnt from users where phone = '$phone'";
        $sqlx = mysqli_query($mysqli, $s);         
        while($str = mysqli_fetch_array($sqlx))
        { 
            if((int)$str["cnt"]<1)
            {  
                $param_password = md5($password); 
                //$param_password = password_hash($password, PASSWORD_DEFAULT); 
                $sql="Insert into users (name,designation, phone, password, user_type) values ('$name','$desig','$phone', '$param_password', $type)";
                $result=mysqli_query($mysqli,$sql);
                if($result=="1")
                {                   
                    $msg="<span style='color:green'>Successfully Save.</span>";
                    $name_err="";
                    $phone="";
                    $phone_err="";
                    $desig="";
                    $desig_err="";
                    $password_err ="";
                    $confirm_password_err ="";
                    $name = "";
                    $password ="";
                    $confirm_password ="";
                    $user_name =""; 
                    $type =""; 
                    $ok_username = "";
                    $type_err="";
                } 
                else{
                    $msg="<span style='color:red'>Somthings went wrong!</span>";
                }
            }
            else
            {
                $phone_err = "User with this phone number is already available.";
            }
        }            
    }
          
} 
 ?>
 
 <div class="container-fluid">
 <div class="row"> 
    <div class="col-md-10">
    <p><b><?php echo $msg ?></b></p>
    </div>
</div> 
    <div class="row"> 
        <div class="col-md-12 col-sm-12">
            <div class="card">
                <div class="card-header">
                    Enter Vehicle Details
                </div> 
                <div class="card-body">
                    <form action="user.php" method="POST"  name="form1" onsubmit="return validation()">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group <?php echo (!empty($vehicle_name_err)) ? 'has-error' : ''; ?>">
                                    <label>Vehicle Name</label>
                                    <input type="text" name="name"  tabindex="1" class="form-control" required value="<?php echo $name; ?>">
                                    <span class="help-block"><?php echo $vehicle_name_err; ?></span>
                                </div> 
                               
                                <div class="form-group <?php echo (!empty($owners_err)) ? 'has-error' : ''; ?>">
                                    <label>Owner's Name</label>
                                    <input type="text" name="owner" tabindex="3" class="form-control" required value="<?php echo $owner; ?>">
                                    <span class="help-block"><?php echo $owners_err; ?></span>
                                </div> 
                                <div class="form-group"> 
                                    <input type="checkbox" id="vehicle1" name="vehicle1" value="Bike">
                                    <label for="vehicle1"> Owner and driver is same</label> 
                                </div> 
                                <div class="form-group <?php echo (!empty($driver_err)) ? 'has-error' : ''; ?>">
                                    <label>Driver's Name</label>
                                    <input type="text" name="driver" tabindex="5" class="form-control" required value="<?php echo $driver; ?>">
                                    <span class="help-block"><?php echo $driver_err; ?></span>
                                </div>    
                                <div class="form-group <?php echo (!empty($type_err)) ? 'has-error' : ''; ?>">
                                    <label>Vehicle Type</label>
                                    <select name="type" required tabindex="7"  class="form-control" >
                                        <?php    $vehicle_types = mysqli_query($mysqli, "SELECT * from vehicle_types"); ?>
                                        <option value="">--Select--</option>
                                        <?php while($r= mysqli_fetch_array($vehicle_types)) { ?>
                                             <option value="<?php echo $r["id"]; ?>"   > <?php echo  $r["name"]; ?></option>
                                        <?php } ?>  
                                    </select>
                                    <span class="help-block"><?php echo $type_err; ?></span>
                                </div>   
                                <div class="form-group <?php echo (!empty($fuel_err)) ? 'has-error' : ''; ?>">
                                    <label>Fuel Type</label>
                                    <select name="fuel" required  tabindex="9" class="form-control" >
                                        <?php    $fuels = mysqli_query($mysqli, "SELECT * from fuels"); ?>
                                        <option value="">--Select--</option>
                                        <?php while($r= mysqli_fetch_array($fuels)) { ?>
                                             <option value="<?php echo $r["id"]; ?>"   > <?php echo  $r["name"]; ?></option>
                                        <?php } ?>  
                                    </select>
                                    <span class="help-block"><?php echo $fuel_err; ?></span>
                                </div>
                                <div class="form-group <?php echo (!empty($used_err)) ? 'has-error' : ''; ?>">
                                    <label>Used as</label>
                                    <select name="used_type" required tabindex="11"  class="form-control" >
                                        <?php    $election_types = mysqli_query($mysqli, "SELECT * from election_types"); ?>
                                        <option value="">--Select--</option>
                                        <?php while($r= mysqli_fetch_array($election_types)) { ?>
                                             <option value="<?php echo $r["id"]; ?>"   > <?php echo  $r["name"]; ?></option>
                                        <?php } ?>  
                                    </select>
                                    <span class="help-block"><?php echo $used_err; ?></span>
                                </div>
                              
                            </div>
                            <div class="col-md-6">
                                <div class="form-group <?php echo (!empty($reg_err)) ? 'has-error' : ''; ?>">
                                        <label>Vehicle Registration Number</label>
                                        <input type="text" name="reg" tabindex="2" class="form-control" required value="<?php echo $reg; ?>">
                                        <span class="help-block"><?php echo $reg_err; ?></span>
                                    </div> 
                                    <div class="form-group <?php echo (!empty($owner_ph_err)) ? 'has-error' : ''; ?>">
                                        <label>Owner's Phone</label>
                                        <input type="text" name="owner_ph" tabindex="4" class="form-control" required value="<?php echo $owner_ph; ?>">
                                        <span class="help-block"><?php echo $owner_ph_err; ?></span>
                                    </div> 
                                    <div class="form-group">  
                                        <label style="visibility:hidden" for="vehicle1"> Owner and driver is same</label> 
                                    </div> 
                                    <div class="form-group <?php echo (!empty($driver_ph_err)) ? 'has-error' : ''; ?>">
                                        <label>Driver's Phone</label>
                                        <input type="text" name="driver_ph" tabindex="6"  class="form-control" required value="<?php echo $driver_ph; ?>">
                                        <span class="help-block"><?php echo $driver_ph_err; ?></span>
                                    </div>    
                                    <div class="form-group <?php echo (!empty($seat_err)) ? 'has-error' : ''; ?>">
                                        <label>Seating Capacity</label>
                                        <input type="text" name="seat" tabindex="8"  class="form-control" required value="<?php echo $seat; ?>">
                                        <span class="help-block"><?php echo $seat_err; ?></span>
                                    </div>   
                                    <div class="form-group <?php echo (!empty($date_on_err)) ? 'has-error' : ''; ?>">
                                        <label>Used From</label>
                                        <input type="text" name="used_from" tabindex="10"   class="form-control"  required value="<?php echo $used_from; ?>">
                                        <span class="help-block"><?php echo $date_on_err; ?></span>
                                    </div>
                                    <div class="form-group">
                                        <label style="visibility :hidden">Used From</label>
                                        <div class="form-group">
                                        <input type="submit" name="Submit" value="Submit" tabindex="12"  class="btn btn-primary"  > 
                                        <a href="users.php" tabindex="13"  class="btn btn-default">Reset</a> 
                                        </div>
                                       
                                    </div>
                            </div>
                        </div>
                    </form> 
                </div> 
            </div>
        </div> 
    
    </div> 
</div>

<?php 
include("../layout/footer.php"); 
?>