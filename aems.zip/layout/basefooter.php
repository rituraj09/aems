<!-- Bootstrap and necessary plugins -->
<script src="../layout/vendors/js/jquery.min.js"></script>
  <script src="../layout/vendors/js/popper.min.js"></script>
  <script src="../layout/vendors/js/bootstrap.min.js"></script> 

  
  <!-- Plugins and scripts required by all views -->
 

  <!-- CoreUI Pro main scripts -->

  <script src="../layout/js/app.js"></script>

  <!-- Plugins and scripts required by this views --> 
  <script src="../layout/vendors/js/moment.min.js"></script> 
  <!-- Custom scripts required by this view -->
  <script src="../layout/js/views/main.js"></script> 
</body>
</html>