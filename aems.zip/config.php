<?php
$servername = "localhost";
$username = "root";
$password = "";
$db = "eleglt";

// Create connection
$mysqli = mysqli_connect($servername, $username, $password, $db); 
?>