<?php
include("../config.php"); 
include("../layout/baseheader.php");
?>

<div class="container-fluid">
    <div class="row"> 
        <div class="col-md-12 col-sm-12">
            <div class="card">
                <div class="card-body">
                    <center><h3><b class="text-danger">NIRVACHAN</b><span class="text-info"> Golaghat</span></h3></center>
                </div>
                <div class="card-body">
                <center> Click here to download <b> Nirvachan Golaghat</b> app ==>> <a href="sahayak.apk" class="btn btn-info text-white">Download</a></center>
                </div>
            </div>
        </div>
    </div>
</div>

<?php 
include("../layout/basefooter.php"); 
?>