//Tooltips are opt-in for performance reasons, so you must initialize them yourself.

$(function () {
  $('[data-toggle="tooltip"]').tooltip()
})
