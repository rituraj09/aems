</main>
</div>
  <footer class="app-footer">
    <span><a href="#">District Administration</a> © 2021 Golaghat.</span>
    <span class="ml-auto">Powered by <a href="https://golaghat.gov.in/">District Administration, Golaghat</a></span>
  </footer>